//Slideshow funtionality

function changeImage() {
    var image = document.getElementById('myImage');
    if (image.src.match("tat1")) {
        image.src = "tat2.jpg";
    }
    else if(image.src.match("tat2")) {
        image.src = "tat3.jpg";
    }
    else if(image.src.match("tat3")) {
        image.src = "tat4.jpg";
    }
    else if(image.src.match("tat4")) {
        image.src = "tat5.jpg";
    } else if(image.src.match("tat5")) {
        image.src = "tat6.jpg";
    }
    else{
        image.src = "tat1.jpg";
    }
}